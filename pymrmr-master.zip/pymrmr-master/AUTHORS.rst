=======
Credits
=======

Development Lead
----------------

* Francesco G. Brundu <francesco.brundu@gmail.com>

Contributors
------------

* Hanchuan Peng (original author - http://home.penglab.com/proj/mRMR/)
