=====
Usage
=====

To use PymRMR in a project::

    import pymrmr
